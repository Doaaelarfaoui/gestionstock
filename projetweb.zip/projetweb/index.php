<?php
require_once 'config/database.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion de Stock - Accueil</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Système de Gestion de Stock</h1>
            <nav>
                <ul>
                    <li><a href="index.php" class="active">Accueil</a></li>
                    <li><a href="login.php">Connexion</a></li>
                </ul>
            </nav>
        </header>

        <main>
            <section class="hero">
                <h2>Bienvenue sur notre plateforme de gestion de stock</h2>
                <p>Une solution complète pour gérer efficacement votre inventaire de produits</p>
            </section>

            <section class="features">
                <h3>Fonctionnalités principales</h3>
                <div class="feature-grid">
                    <div class="feature-card">
                        <h4>📦 Gestion des Produits</h4>
                        <p>Ajoutez, modifiez et supprimez vos produits en toute simplicité. Suivez les quantités en stock et les prix.</p>
                    </div>
                    <div class="feature-card">
                        <h4>📊 Catégories</h4>
                        <p>Organisez vos produits par catégories pour une meilleure gestion et recherche.</p>
                    </div>
                    <div class="feature-card">
                        <h4>🔍 Recherche Rapide</h4>
                        <p>Trouvez rapidement vos produits grâce à notre système de recherche intégré.</p>
                    </div>
                    <div class="feature-card">
                        <h4>🔒 Sécurisé</h4>
                        <p>Accès protégé par authentification pour garantir la sécurité de vos données.</p>
                    </div>
                </div>
            </section>

            <section class="about">
                <h3>À propos du système</h3>
                <p>Ce système de gestion de stock a été développé pour répondre aux besoins des entreprises souhaitant optimiser la gestion de leur inventaire. Il permet de :</p>
                <ul>
                    <li>Maintenir un inventaire précis et à jour</li>
                    <li>Suivre les mouvements de stock en temps réel</li>
                    <li>Organiser les produits par catégories</li>
                    <li>Générer des rapports sur l'état du stock</li>
                </ul>
            </section>

            <section class="cta">
                <h3>Prêt à commencer ?</h3>
                <p>Connectez-vous pour accéder à votre tableau de bord et commencer à gérer votre stock.</p>
                <a href="login.php" class="btn-primary">Se connecter</a>
            </section>
        </main>

        <footer>
            <p>&copy; 2024 Système de Gestion de Stock. Tous droits réservés.</p>
        </footer>
    </div>
</body>
</html>