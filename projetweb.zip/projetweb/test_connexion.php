<?php
// Test de connexion à la base de données

define('DB_HOST', 'localhost');
define('DB_NAME', 'gestion_stock');
define('DB_USER', 'root');
define('DB_PASS', '');

echo "<h2>Test de connexion</h2>";

// Test 1: Connexion à MySQL
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("❌ Erreur de connexion: " . $conn->connect_error);
}

echo "✅ Connexion à la base de données OK<br><br>";

// Test 2: Vérifier si la table existe
$result = $conn->query("SHOW TABLES LIKE 'utilisateurs'");
if ($result->num_rows > 0) {
    echo "✅ Table 'utilisateurs' existe<br><br>";
} else {
    echo "❌ Table 'utilisateurs' n'existe pas<br><br>";
}

// Test 3: Compter les utilisateurs
$count = $conn->query("SELECT COUNT(*) as nb FROM utilisateurs")->fetch_assoc()['nb'];
echo "📊 Nombre d'utilisateurs dans la base: <strong>" . $count . "</strong><br><br>";

// Test 4: Afficher tous les utilisateurs
echo "<h3>Liste des utilisateurs:</h3>";
$result = $conn->query("SELECT id, username, nom_complet FROM utilisateurs");

if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>ID</th><th>Username</th><th>Nom complet</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['nom_complet'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "⚠️ Aucun utilisateur trouvé<br>";
}

echo "<br><hr><br>";

// Test 5: Créer un utilisateur de test
echo "<h3>Création d'un utilisateur de test:</h3>";

// Supprimer l'ancien s'il existe
$conn->query("DELETE FROM utilisateurs WHERE username = 'admin'");

// Créer le nouveau
$username = 'admin';
$password = 'admin123';
$password_hash = password_hash($password, PASSWORD_DEFAULT);
$nom_complet = 'Administrateur Test';

$stmt = $conn->prepare("INSERT INTO utilisateurs (username, password, nom_complet) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $username, $password_hash, $nom_complet);

if ($stmt->execute()) {
    echo "✅ Utilisateur créé avec succès!<br>";
    echo "Username: <strong>admin</strong><br>";
    echo "Password: <strong>admin123</strong><br>";
    echo "Hash: <code>" . $password_hash . "</code><br><br>";
    
    // Test 6: Vérifier la connexion
    echo "<h3>Test de vérification du mot de passe:</h3>";
    $check = $conn->query("SELECT password FROM utilisateurs WHERE username = 'admin'")->fetch_assoc();
    
    if (password_verify($password, $check['password'])) {
        echo "✅ Le mot de passe fonctionne correctement!<br><br>";
        echo "<a href='login.php' style='display:inline-block; padding:10px 20px; background:#2563eb; color:white; text-decoration:none; border-radius:5px;'>Aller à la connexion</a>";
    } else {
        echo "❌ Erreur: Le mot de passe ne correspond pas!<br>";
    }
} else {
    echo "❌ Erreur lors de la création: " . $conn->error . "<br>";
}

$stmt->close();
$conn->close();
?>
```

### 3️⃣ Exécute ce fichier

Ouvre dans ton navigateur :
```
http://localhost/projetweb/test_connexion.php