<?php
require_once 'config/database.php';
requireLogin();

$conn = getConnection();

// Statistiques
$total_produits = $conn->query("SELECT COUNT(*) as total FROM produits")->fetch_assoc()['total'];
$total_categories = $conn->query("SELECT COUNT(*) as total FROM categories")->fetch_assoc()['total'];
$valeur_stock = $conn->query("SELECT SUM(prix * quantite) as valeur FROM produits")->fetch_assoc()['valeur'];
$produits_faible_stock = $conn->query("SELECT COUNT(*) as total FROM produits WHERE quantite < 10")->fetch_assoc()['total'];

$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - Gestion de Stock</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Système de Gestion de Stock</h1>
            <nav>
                <ul>
                    <li><a href="dashboard.php" class="active">Tableau de bord</a></li>
                    <li><a href="crud_principal/list.php">Produits</a></li>
                    <li><a href="crud_secondaire/list.php">Catégories</a></li>
                    <li><a href="logout.php">Déconnexion</a></li>
                </ul>
            </nav>
            <div class="user-info">
                Connecté en tant que : <strong><?php echo htmlspecialchars($_SESSION['nom_complet']); ?></strong>
            </div>
        </header>

        <main>
            <h2>Tableau de bord</h2>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Produits</h3>
                    <p class="stat-number"><?php echo $total_produits; ?></p>
                    <p class="stat-label">produits en stock</p>
                </div>
                
                <div class="stat-card">
                    <h3>Catégories</h3>
                    <p class="stat-number"><?php echo $total_categories; ?></p>
                    <p class="stat-label">catégories actives</p>
                </div>
                
                <div class="stat-card">
                    <h3>Valeur du Stock</h3>
                    <p class="stat-number"><?php echo number_format($valeur_stock, 2); ?> DH</p>
                    <p class="stat-label">valeur totale</p>
                </div>
                
                <div class="stat-card alert-card">
                    <h3>Stock Faible</h3>
                    <p class="stat-number"><?php echo $produits_faible_stock; ?></p>
                    <p class="stat-label">produits < 10 unités</p>
                </div>
            </div>

            <div class="quick-actions">
                <h3>Actions rapides</h3>
                <div class="action-buttons">
                    <a href="crud_principal/add.php" class="btn-primary">Ajouter un produit</a>
                    <a href="crud_principal/list.php" class="btn-secondary">Voir les produits</a>
                    <a href="crud_secondaire/add.php" class="btn-secondary">Ajouter une catégorie</a>
                    <a href="crud_secondaire/list.php" class="btn-secondary">Voir les catégories</a>
                </div>
            </div>

            <div class="info-section">
                <h3>Bienvenue sur votre tableau de bord</h3>
                <p>Utilisez le menu de navigation ci-dessus pour gérer vos produits et catégories. Vous pouvez :</p>
                <ul>
                    <li>Ajouter, modifier et supprimer des produits</li>
                    <li>Organiser vos produits par catégories</li>
                    <li>Rechercher rapidement des produits spécifiques</li>
                    <li>Suivre l'état de votre stock en temps réel</li>
                </ul>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Système de Gestion de Stock. Tous droits réservés.</p>
        </footer>
    </div>
</body>
</html>