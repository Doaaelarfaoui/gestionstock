<?php
require_once '../config/database.php';
requireLogin();

$error = '';
$success = '';

$conn = getConnection();

// Vérifier si l'ID est fourni
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list.php");
    exit();
}

$id = cleanInput($_GET['id']);

// Récupérer les informations du produit
$stmt = $conn->prepare("SELECT * FROM produits WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: list.php?success=" . urlencode("Produit introuvable"));
    exit();
}

$produit = $result->fetch_assoc();
$stmt->close();

// Récupérer les catégories
$categories = $conn->query("SELECT * FROM categories ORDER BY nom ASC");

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = cleanInput($_POST['nom']);
    $reference = cleanInput($_POST['reference']);
    $description = cleanInput($_POST['description']);
    $prix = cleanInput($_POST['prix']);
    $quantite = cleanInput($_POST['quantite']);
    $id_categorie = cleanInput($_POST['id_categorie']);
    
    // Validation des champs
    if (empty($nom) || empty($reference) || empty($prix) || empty($quantite) || empty($id_categorie)) {
        $error = "Tous les champs obligatoires doivent être remplis";
    } elseif (!is_numeric($prix) || $prix < 0) {
        $error = "Le prix doit être un nombre positif";
    } elseif (!is_numeric($quantite) || $quantite < 0) {
        $error = "La quantité doit être un nombre positif";
    } else {
        // Vérifier si la référence existe déjà (sauf pour ce produit)
        $check_stmt = $conn->prepare("SELECT id FROM produits WHERE reference = ? AND id != ?");
        $check_stmt->bind_param("si", $reference, $id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $error = "Cette référence est déjà utilisée par un autre produit";
        } else {
            // Mise à jour dans la base de données
            $update_stmt = $conn->prepare("UPDATE produits SET nom = ?, reference = ?, description = ?, prix = ?, quantite = ?, id_categorie = ? WHERE id = ?");
            $update_stmt->bind_param("sssdiis", $nom, $reference, $description, $prix, $quantite, $id_categorie, $id);
            
            if ($update_stmt->execute()) {
                header("Location: list.php?success=" . urlencode("Produit modifié avec succès"));
                exit();
            } else {
                $error = "Erreur lors de la modification du produit : " . $conn->error;
            }
            $update_stmt->close();
        }
        $check_stmt->close();
    }
} else {
    // Pré-remplir les variables avec les données existantes
    $nom = $produit['nom'];
    $reference = $produit['reference'];
    $description = $produit['description'];
    $prix = $produit['prix'];
    $quantite = $produit['quantite'];
    $id_categorie = $produit['id_categorie'];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un Produit - Gestion de Stock</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Système de Gestion de Stock</h1>
            <nav>
                <ul>
                    <li><a href="../dashboard.php">Tableau de bord</a></li>
                    <li><a href="list.php" class="active">Produits</a></li>
                    <li><a href="../crud_secondaire/list.php">Catégories</a></li>
                    <li><a href="../logout.php">Déconnexion</a></li>
                </ul>
            </nav>
            <div class="user-info">
                Connecté en tant que : <strong><?php echo htmlspecialchars($_SESSION['nom_complet']); ?></strong>
            </div>
        </header>

        <main>
            <div class="page-header">
                <h2>Modifier le Produit</h2>
                <a href="list.php" class="btn-secondary">Retour à la liste</a>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" action="edit.php?id=<?php echo $id; ?>">
                    <div class="form-group">
                        <label for="nom">Nom du produit *</label>
                        <input type="text" id="nom" name="nom" required 
                               value="<?php echo htmlspecialchars($nom); ?>">
                    </div>

                    <div class="form-group">
                        <label for="reference">Référence *</label>
                        <input type="text" id="reference" name="reference" required 
                               value="<?php echo htmlspecialchars($reference); ?>">
                        <small>La référence doit être unique</small>
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" rows="4"><?php echo htmlspecialchars($description); ?></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="prix">Prix (DH) *</label>
                            <input type="number" id="prix" name="prix" step="0.01" min="0" required 
                                   value="<?php echo htmlspecialchars($prix); ?>">
                        </div>

                        <div class="form-group">
                            <label for="quantite">Quantité *</label>
                            <input type="number" id="quantite" name="quantite" min="0" required 
                                   value="<?php echo htmlspecialchars($quantite); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="id_categorie">Catégorie *</label>
                        <select id="id_categorie" name="id_categorie" required>
                            <option value="">-- Sélectionnez une catégorie --</option>
                            <?php while ($cat = $categories->fetch_assoc()): ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                        <?php echo ($id_categorie == $cat['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['nom']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-primary">Modifier le produit</button>
                        <a href="list.php" class="btn-secondary">Annuler</a>
                    </div>
                </form>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Système de Gestion de Stock. Tous droits réservés.</p>
        </footer>
    </div>
</body>
</html>
<?php
$conn->close();
?>