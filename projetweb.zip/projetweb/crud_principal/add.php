<?php
require_once '../config/database.php';
requireLogin();

$error = '';
$success = '';

$conn = getConnection();

// Récupérer les catégories pour le formulaire
$categories = $conn->query("SELECT * FROM categories ORDER BY nom ASC");

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = cleanInput($_POST['nom']);
    $reference = cleanInput($_POST['reference']);
    $description = cleanInput($_POST['description']);
    $prix = cleanInput($_POST['prix']);
    $quantite = cleanInput($_POST['quantite']);
    $id_categorie = cleanInput($_POST['id_categorie']);
    
    // Validation des champs
    if (empty($nom) || empty($reference) || empty($prix) || empty($quantite) || empty($id_categorie)) {
        $error = "Tous les champs obligatoires doivent être remplis";
    } elseif (!is_numeric($prix) || $prix < 0) {
        $error = "Le prix doit être un nombre positif";
    } elseif (!is_numeric($quantite) || $quantite < 0) {
        $error = "La quantité doit être un nombre positif";
    } else {
        // Vérifier si la référence existe déjà
        $check_stmt = $conn->prepare("SELECT id FROM produits WHERE reference = ?");
        $check_stmt->bind_param("s", $reference);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $error = "Cette référence existe déjà";
        } else {
            // Insertion dans la base de données
            $stmt = $conn->prepare("INSERT INTO produits (nom, reference, description, prix, quantite, id_categorie) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssdii", $nom, $reference, $description, $prix, $quantite, $id_categorie);
            
            if ($stmt->execute()) {
                header("Location: list.php?success=" . urlencode("Produit ajouté avec succès"));
                exit();
            } else {
                $error = "Erreur lors de l'ajout du produit : " . $conn->error;
            }
            $stmt->close();
        }
        $check_stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Produit - Gestion de Stock</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Système de Gestion de Stock</h1>
            <nav>
                <ul>
                    <li><a href="../dashboard.php">Tableau de bord</a></li>
                    <li><a href="list.php" class="active">Produits</a></li>
                    <li><a href="../crud_secondaire/list.php">Catégories</a></li>
                    <li><a href="../logout.php">Déconnexion</a></li>
                </ul>
            </nav>
            <div class="user-info">
                Connecté en tant que : <strong><?php echo htmlspecialchars($_SESSION['nom_complet']); ?></strong>
            </div>
        </header>

        <main>
            <div class="page-header">
                <h2>Ajouter un Produit</h2>
                <a href="list.php" class="btn-secondary">Retour à la liste</a>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" action="add.php">
                    <div class="form-group">
                        <label for="nom">Nom du produit *</label>
                        <input type="text" id="nom" name="nom" required 
                               value="<?php echo isset($nom) ? htmlspecialchars($nom) : ''; ?>">
                    </div>

                    <div class="form-group">
                        <label for="reference">Référence *</label>
                        <input type="text" id="reference" name="reference" required 
                               value="<?php echo isset($reference) ? htmlspecialchars($reference) : ''; ?>">
                        <small>La référence doit être unique</small>
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" rows="4"><?php echo isset($description) ? htmlspecialchars($description) : ''; ?></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="prix">Prix (DH) *</label>
                            <input type="number" id="prix" name="prix" step="0.01" min="0" required 
                                   value="<?php echo isset($prix) ? htmlspecialchars($prix) : ''; ?>">
                        </div>

                        <div class="form-group">
                            <label for="quantite">Quantité *</label>
                            <input type="number" id="quantite" name="quantite" min="0" required 
                                   value="<?php echo isset($quantite) ? htmlspecialchars($quantite) : ''; ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="id_categorie">Catégorie *</label>
                        <select id="id_categorie" name="id_categorie" required>
                            <option value="">-- Sélectionnez une catégorie --</option>
                            <?php while ($cat = $categories->fetch_assoc()): ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                        <?php echo (isset($id_categorie) && $id_categorie == $cat['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['nom']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-primary">Ajouter le produit</button>
                        <a href="list.php" class="btn-secondary">Annuler</a>
                    </div>
                </form>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Système de Gestion de Stock. Tous droits réservés.</p>
        </footer>
    </div>
</body>
</html>
<?php
$conn->close();
?>