<?php
require_once '../config/database.php';
requireLogin();

$conn = getConnection();

// Gestion de la recherche
$search = isset($_GET['search']) ? cleanInput($_GET['search']) : '';

// Construction de la requête SQL
if (!empty($search)) {
    $sql = "SELECT p.*, c.nom as categorie_nom 
            FROM produits p 
            INNER JOIN categories c ON p.id_categorie = c.id 
            WHERE p.nom LIKE ? OR p.reference LIKE ? OR p.description LIKE ?
            ORDER BY p.date_ajout DESC";
    $stmt = $conn->prepare($sql);
    $search_param = "%$search%";
    $stmt->bind_param("sss", $search_param, $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql = "SELECT p.*, c.nom as categorie_nom 
            FROM produits p 
            INNER JOIN categories c ON p.id_categorie = c.id 
            ORDER BY p.date_ajout DESC";
    $result = $conn->query($sql);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Produits - Gestion de Stock</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Système de Gestion de Stock</h1>
            <nav>
                <ul>
                    <li><a href="../dashboard.php">Tableau de bord</a></li>
                    <li><a href="list.php" class="active">Produits</a></li>
                    <li><a href="../crud_secondaire/list.php">Catégories</a></li>
                    <li><a href="../logout.php">Déconnexion</a></li>
                </ul>
            </nav>
            <div class="user-info">
                Connecté en tant que : <strong><?php echo htmlspecialchars($_SESSION['nom_complet']); ?></strong>
            </div>
        </header>

        <main>
            <div class="page-header">
                <h2>Liste des Produits</h2>
                <a href="add.php" class="btn-primary">Ajouter un produit</a>
            </div>

            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
            <?php endif; ?>

            <div class="search-box">
                <form method="GET" action="list.php">
                    <input type="text" name="search" placeholder="Rechercher un produit..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit" class="btn-secondary">Rechercher</button>
                    <?php if (!empty($search)): ?>
                        <a href="list.php" class="btn-secondary">Réinitialiser</a>
                    <?php endif; ?>
                </form>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Référence</th>
                            <th>Nom</th>
                            <th>Catégorie</th>
                            <th>Prix (DH)</th>
                            <th>Quantité</th>
                            <th>Date d'ajout</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr <?php echo $row['quantite'] < 10 ? 'class="low-stock"' : ''; ?>>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo htmlspecialchars($row['reference']); ?></td>
                                    <td><?php echo htmlspecialchars($row['nom']); ?></td>
                                    <td><?php echo htmlspecialchars($row['categorie_nom']); ?></td>
                                    <td><?php echo number_format($row['prix'], 2); ?></td>
                                    <td>
                                        <span class="stock-badge <?php echo $row['quantite'] < 10 ? 'stock-low' : 'stock-ok'; ?>">
                                            <?php echo $row['quantite']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($row['date_ajout'])); ?></td>
                                    <td class="action-buttons">
                                        <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn-edit">Modifier</a>
                                        <a href="delete.php?id=<?php echo $row['id']; ?>" 
                                           class="btn-delete" 
                                           onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce produit ?');">
                                            Supprimer
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="no-data">
                                    <?php echo !empty($search) ? 'Aucun produit trouvé pour cette recherche.' : 'Aucun produit disponible.'; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Système de Gestion de Stock. Tous droits réservés.</p>
        </footer>
    </div>
</body>
</html>
<?php
$conn->close();
?>