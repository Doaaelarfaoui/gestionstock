<?php
require_once '../config/database.php';
requireLogin();

// Vérifier si l'ID est fourni
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list.php");
    exit();
}

$id = cleanInput($_GET['id']);
$conn = getConnection();

// Vérifier si le produit existe
$stmt = $conn->prepare("SELECT nom FROM produits WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: list.php?success=" . urlencode("Produit introuvable"));
    exit();
}

$produit = $result->fetch_assoc();
$stmt->close();

// Confirmation de suppression
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $delete_stmt = $conn->prepare("DELETE FROM produits WHERE id = ?");
    $delete_stmt->bind_param("i", $id);
    
    if ($delete_stmt->execute()) {
        $delete_stmt->close();
        $conn->close();
        header("Location: list.php?success=" . urlencode("Produit supprimé avec succès"));
        exit();
    } else {
        $error = "Erreur lors de la suppression : " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer un Produit - Gestion de Stock</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Système de Gestion de Stock</h1>
            <nav>
                <ul>
                    <li><a href="../dashboard.php">Tableau de bord</a></li>
                    <li><a href="list.php" class="active">Produits</a></li>
                    <li><a href="../crud_secondaire/list.php">Catégories</a></li>
                    <li><a href="../logout.php">Déconnexion</a></li>
                </ul>
            </nav>
            <div class="user-info">
                Connecté en tant que : <strong><?php echo htmlspecialchars($_SESSION['nom_complet']); ?></strong>
            </div>
        </header>

        <main>
            <div class="page-header">
                <h2>Supprimer le Produit</h2>
                <a href="list.php" class="btn-secondary">Retour à la liste</a>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="delete-confirmation">
                <div class="warning-icon">⚠️</div>
                <h3>Confirmation de suppression</h3>
                <p>Êtes-vous sûr de vouloir supprimer le produit suivant ?</p>
                <div class="product-info">
                    <strong><?php echo htmlspecialchars($produit['nom']); ?></strong>
                </div>
                <p class="warning-text">Cette action est irréversible !</p>
                
                <form method="POST" action="delete.php?id=<?php echo $id; ?>">
                    <div class="form-actions">
                        <button type="submit" class="btn-delete">Confirmer la suppression</button>
                        <a href="list.php" class="btn-secondary">Annuler</a>
                    </div>
                </form>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Système de Gestion de Stock. Tous droits réservés.</p>
        </footer>
    </div>
</body>
</html>
<?php
$conn->close();
?>