<?php
require_once '../config/database.php';
requireLogin();

$conn = getConnection();

// Récupérer les catégories avec le nombre de produits
$sql = "SELECT c.*, COUNT(p.id) as nb_produits 
        FROM categories c 
        LEFT JOIN produits p ON c.id = p.id_categorie 
        GROUP BY c.id 
        ORDER BY c.nom ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Catégories - Gestion de Stock</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Système de Gestion de Stock</h1>
            <nav>
                <ul>
                    <li><a href="../dashboard.php">Tableau de bord</a></li>
                    <li><a href="../crud_principal/list.php">Produits</a></li>
                    <li><a href="list.php" class="active">Catégories</a></li>
                    <li><a href="../logout.php">Déconnexion</a></li>
                </ul>
            </nav>
            <div class="user-info">
                Connecté en tant que : <strong><?php echo htmlspecialchars($_SESSION['nom_complet']); ?></strong>
            </div>
        </header>

        <main>
            <div class="page-header">
                <h2>Liste des Catégories</h2>
                <a href="add.php" class="btn-primary">Ajouter une catégorie</a>
            </div>

            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></div>
            <?php endif; ?>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Description</th>
                            <th>Nombre de produits</th>
                            <th>Date de création</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><strong><?php echo htmlspecialchars($row['nom']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($row['description']); ?></td>
                                    <td>
                                        <span class="badge"><?php echo $row['nb_produits']; ?> produit(s)</span>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($row['date_creation'])); ?></td>
                                    <td class="action-buttons">
                                        <?php if ($row['nb_produits'] == 0): ?>
                                            <a href="delete.php?id=<?php echo $row['id']; ?>" 
                                               class="btn-delete" 
                                               onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette catégorie ?');">
                                                Supprimer
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted" title="Impossible de supprimer une catégorie contenant des produits">
                                                Non supprimable
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="no-data">Aucune catégorie disponible.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="info-box">
                <strong>Note :</strong> Vous ne pouvez supprimer que les catégories qui ne contiennent aucun produit.
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Système de Gestion de Stock. Tous droits réservés.</p>
        </footer>
    </div>
</body>
</html>
<?php
$conn->close();
?>