<?php
require_once '../config/database.php';
requireLogin();

// Vérifier si l'ID est fourni
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: list.php");
    exit();
}

$id = cleanInput($_GET['id']);
$conn = getConnection();

// Vérifier si la catégorie existe
$stmt = $conn->prepare("SELECT nom FROM categories WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: list.php?success=" . urlencode("Catégorie introuvable"));
    exit();
}

$categorie = $result->fetch_assoc();
$stmt->close();

// Vérifier si la catégorie contient des produits
$check_stmt = $conn->prepare("SELECT COUNT(*) as nb FROM produits WHERE id_categorie = ?");
$check_stmt->bind_param("i", $id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();
$nb_produits = $check_result->fetch_assoc()['nb'];
$check_stmt->close();

if ($nb_produits > 0) {
    header("Location: list.php?success=" . urlencode("Impossible de supprimer une catégorie contenant des produits"));
    exit();
}

// Confirmation de suppression
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $delete_stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
    $delete_stmt->bind_param("i", $id);
    
    if ($delete_stmt->execute()) {
        $delete_stmt->close();
        $conn->close();
        header("Location: list.php?success=" . urlencode("Catégorie supprimée avec succès"));
        exit();
    } else {
        $error = "Erreur lors de la suppression : " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer une Catégorie - Gestion de Stock</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Système de Gestion de Stock</h1>
            <nav>
                <ul>
                    <li><a href="../dashboard.php">Tableau de bord</a></li>
                    <li><a href="../crud_principal/list.php">Produits</a></li>
                    <li><a href="list.php" class="active">Catégories</a></li>
                    <li><a href="../logout.php">Déconnexion</a></li>
                </ul>
            </nav>
            <div class="user-info">
                Connecté en tant que : <strong><?php echo htmlspecialchars($_SESSION['nom_complet']); ?></strong>
            </div>
        </header>

        <main>
            <div class="page-header">
                <h2>Supprimer la Catégorie</h2>
                <a href="list.php" class="btn-secondary">Retour à la liste</a>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="delete-confirmation">
                <div class="warning-icon">⚠️</div>
                <h3>Confirmation de suppression</h3>
                <p>Êtes-vous sûr de vouloir supprimer la catégorie suivante ?</p>
                <div class="product-info">
                    <strong><?php echo htmlspecialchars($categorie['nom']); ?></strong>
                </div>
                <p class="warning-text">Cette action est irréversible !</p>
                
                <form method="POST" action="delete.php?id=<?php echo $id; ?>">
                    <div class="form-actions">
                        <button type="submit" class="btn-delete">Confirmer la suppression</button>
                        <a href="list.php" class="btn-secondary">Annuler</a>
                    </div>
                </form>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Système de Gestion de Stock. Tous droits réservés.</p>
        </footer>
    </div>
</body>
</html>
<?php
$conn->close();
?>