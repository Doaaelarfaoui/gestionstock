<?php
require_once '../config/database.php';
requireLogin();

$error = '';
$success = '';

$conn = getConnection();

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = cleanInput($_POST['nom']);
    $description = cleanInput($_POST['description']);
    
    // Validation des champs
    if (empty($nom)) {
        $error = "Le nom de la catégorie est obligatoire";
    } else {
        // Vérifier si la catégorie existe déjà
        $check_stmt = $conn->prepare("SELECT id FROM categories WHERE nom = ?");
        $check_stmt->bind_param("s", $nom);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $error = "Cette catégorie existe déjà";
        } else {
            // Insertion dans la base de données
            $stmt = $conn->prepare("INSERT INTO categories (nom, description) VALUES (?, ?)");
            $stmt->bind_param("ss", $nom, $description);
            
            if ($stmt->execute()) {
                header("Location: list.php?success=" . urlencode("Catégorie ajoutée avec succès"));
                exit();
            } else {
                $error = "Erreur lors de l'ajout de la catégorie : " . $conn->error;
            }
            $stmt->close();
        }
        $check_stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Catégorie - Gestion de Stock</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Système de Gestion de Stock</h1>
            <nav>
                <ul>
                    <li><a href="../dashboard.php">Tableau de bord</a></li>
                    <li><a href="../crud_principal/list.php">Produits</a></li>
                    <li><a href="list.php" class="active">Catégories</a></li>
                    <li><a href="../logout.php">Déconnexion</a></li>
                </ul>
            </nav>
            <div class="user-info">
                Connecté en tant que : <strong><?php echo htmlspecialchars($_SESSION['nom_complet']); ?></strong>
            </div>
        </header>

        <main>
            <div class="page-header">
                <h2>Ajouter une Catégorie</h2>
                <a href="list.php" class="btn-secondary">Retour à la liste</a>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" action="add.php">
                    <div class="form-group">
                        <label for="nom">Nom de la catégorie *</label>
                        <input type="text" id="nom" name="nom" required 
                               value="<?php echo isset($nom) ? htmlspecialchars($nom) : ''; ?>"
                               placeholder="Ex: Électronique, Vêtements, etc.">
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" rows="4" 
                                  placeholder="Description de la catégorie..."><?php echo isset($description) ? htmlspecialchars($description) : ''; ?></textarea>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-primary">Ajouter la catégorie</button>
                        <a href="list.php" class="btn-secondary">Annuler</a>
                    </div>
                </form>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Système de Gestion de Stock. Tous droits réservés.</p>
        </footer>
    </div>
</body>
</html>
<?php
$conn->close();
?>